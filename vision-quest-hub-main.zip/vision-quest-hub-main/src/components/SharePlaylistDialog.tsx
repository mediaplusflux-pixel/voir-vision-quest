import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Share2, Copy, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SharePlaylistDialogProps {
  channelId: string;
}

export const SharePlaylistDialog = ({ channelId }: SharePlaylistDialogProps) => {
  const [open, setOpen] = useState(false);
  const [playlistName, setPlaylistName] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [startImmediately, setStartImmediately] = useState(true);
  const [primaryColor, setPrimaryColor] = useState("18 100% 60%");
  const [backgroundColor, setBackgroundColor] = useState("0 0% 7%");
  const [textColor, setTextColor] = useState("0 0% 98%");
  const [shareUrl, setShareUrl] = useState("");
  const [iframeCode, setIframeCode] = useState("");
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedIframe, setCopiedIframe] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();

  const handleCreateShare = async () => {
    if (!playlistName.trim()) {
      toast({
        title: "Erreur",
        description: "Veuillez entrer un nom pour le partage",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const { data, error } = await supabase.functions.invoke('create-playlist-share', {
        body: {
          name: playlistName,
          channelId,
          scheduledTime: startImmediately ? null : scheduledTime,
          startImmediately,
          playerConfig: {
            primaryColor,
            backgroundColor,
            textColor,
          }
        },
        headers: {
          Authorization: `Bearer ${session?.access_token}`,
        }
      });

      if (error) throw error;

      if (data.success) {
        const baseUrl = window.location.origin;
        const url = `${baseUrl}/shared/${data.shareId}`;
        const iframe = `<iframe src="${url}" width="100%" height="600" frameborder="0" allowfullscreen></iframe>`;
        
        setShareUrl(url);
        setIframeCode(iframe);
        
        toast({
          title: "Partage créé",
          description: "Votre playlist est maintenant partageable",
        });
      }
    } catch (error: any) {
      console.error('Error creating share:', error);
      toast({
        title: "Erreur",
        description: error.message || "Impossible de créer le partage",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const copyToClipboard = async (text: string, type: 'url' | 'iframe') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'url') {
        setCopiedUrl(true);
        setTimeout(() => setCopiedUrl(false), 2000);
      } else {
        setCopiedIframe(true);
        setTimeout(() => setCopiedIframe(false), 2000);
      }
      toast({
        title: "Copié",
        description: type === 'url' ? "Lien copié" : "Code iframe copié",
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de copier",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Share2 className="w-4 h-4" />
          Partage Playlist
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Partager la playlist en temps réel</DialogTitle>
          <DialogDescription>
            Créez un lien de partage pour votre playlist qui se synchronise en temps réel
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {!shareUrl ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="playlist-name">Nom du partage</Label>
                <Input
                  id="playlist-name"
                  placeholder="Ex: Ma playlist live"
                  value={playlistName}
                  onChange={(e) => setPlaylistName(e.target.value)}
                />
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-semibold">Planification de la diffusion</h3>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="start-now"
                    checked={startImmediately}
                    onChange={(e) => setStartImmediately(e.target.checked)}
                    className="rounded"
                  />
                  <Label htmlFor="start-now" className="cursor-pointer">
                    Démarrer immédiatement
                  </Label>
                </div>

                {!startImmediately && (
                  <div className="space-y-2">
                    <Label htmlFor="scheduled-time">Heure de début programmée</Label>
                    <Input
                      id="scheduled-time"
                      type="datetime-local"
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-semibold">Personnaliser le lecteur</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="primary-color">Couleur principale (HSL)</Label>
                  <Input
                    id="primary-color"
                    placeholder="18 100% 60%"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bg-color">Couleur de fond (HSL)</Label>
                  <Input
                    id="bg-color"
                    placeholder="0 0% 7%"
                    value={backgroundColor}
                    onChange={(e) => setBackgroundColor(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="text-color">Couleur du texte (HSL)</Label>
                  <Input
                    id="text-color"
                    placeholder="0 0% 98%"
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                  />
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Lien de partage</Label>
                <div className="flex gap-2">
                  <Input value={shareUrl} readOnly />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => copyToClipboard(shareUrl, 'url')}
                  >
                    {copiedUrl ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Code iframe</Label>
                <div className="flex gap-2">
                  <Input value={iframeCode} readOnly className="font-mono text-xs" />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => copyToClipboard(iframeCode, 'iframe')}
                  >
                    {copiedIframe ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {!shareUrl ? (
            <Button onClick={handleCreateShare} disabled={isCreating}>
              {isCreating ? "Création..." : "Créer partage playlist"}
            </Button>
          ) : (
            <Button variant="outline" onClick={() => {
              setOpen(false);
              setShareUrl("");
              setIframeCode("");
              setPlaylistName("");
            }}>
              Fermer
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};