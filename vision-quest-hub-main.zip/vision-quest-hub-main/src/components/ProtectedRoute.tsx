import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState, useRef } from "react";

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { session, loading, initialized } = useAuth();
  const location = useLocation();
  const [shouldRedirect, setShouldRedirect] = useState(false);
  const redirectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hadSessionRef = useRef(false);

  // Tracker si on a déjà eu une session
  useEffect(() => {
    if (session) {
      hadSessionRef.current = true;
    }
  }, [session]);

  // Gérer la redirection avec un délai pour éviter les faux SIGNED_OUT
  useEffect(() => {
    // Nettoyer le timeout précédent
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (initialized && !loading) {
      if (session) {
        // Session valide, pas de redirection
        setShouldRedirect(false);
      } else if (!hadSessionRef.current) {
        // Jamais eu de session (premier chargement sans connexion)
        setShouldRedirect(true);
      } else {
        // Avait une session mais plus maintenant
        // Attendre 500ms avant de rediriger pour éviter les faux positifs
        redirectTimeoutRef.current = setTimeout(() => {
          setShouldRedirect(true);
        }, 500);
      }
    }

    return () => {
      if (redirectTimeoutRef.current) {
        clearTimeout(redirectTimeoutRef.current);
      }
    };
  }, [session, loading, initialized]);

  // Afficher le chargement tant que l'auth n'est pas initialisée
  if (loading || !initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-foreground">Chargement...</div>
      </div>
    );
  }

  // Rediriger vers /auth uniquement si confirmé après le délai
  if (!session && shouldRedirect) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // Si on a une session OU qu'on attend encore le délai, afficher le contenu
  if (session || !shouldRedirect) {
    return <>{children}</>;
  }

  // État de transition, afficher le contenu
  return <>{children}</>;
};

export default ProtectedRoute;
