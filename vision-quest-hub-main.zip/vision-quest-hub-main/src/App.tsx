import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LicenseProvider } from "@/contexts/LicenseContext";
import { PlaylistProvider } from "@/contexts/PlaylistContext";
import Antenne from "./pages/Antenne";
import Bibliotheque from "./pages/Bibliotheque";
import Chaines from "./pages/Chaines";
import Grille from "./pages/Grille";
import Transmission from "./pages/Transmission";
import NotFound from "./pages/NotFound";
import SharedPlaylist from "./pages/SharedPlaylist";
import PublicPlayer from "./pages/PublicPlayer";
import Auth from "./pages/Auth";
import Profile from "./pages/Profile";
import ProtectedRoute from "./components/ProtectedRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <LicenseProvider>
          <PlaylistProvider>
            <Routes>
              <Route path="/auth" element={<Auth />} />
              <Route path="/" element={<ProtectedRoute><Antenne /></ProtectedRoute>} />
              <Route path="/chaines" element={<ProtectedRoute><Chaines /></ProtectedRoute>} />
              <Route path="/bibliotheque" element={<ProtectedRoute><Bibliotheque /></ProtectedRoute>} />
              <Route path="/grille" element={<ProtectedRoute><Grille /></ProtectedRoute>} />
              <Route path="/transmission" element={<ProtectedRoute><Transmission /></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
              <Route path="/shared/:shareId" element={<SharedPlaylist />} />
              <Route path="/live" element={<PublicPlayer />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </PlaylistProvider>
        </LicenseProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
