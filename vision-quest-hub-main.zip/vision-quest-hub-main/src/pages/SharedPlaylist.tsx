import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import VideoPlayer from "@/components/VideoPlayer";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface PlayerConfig {
  primaryColor: string;
  backgroundColor: string;
  textColor: string;
}

interface PlaylistShare {
  id: string;
  share_id: string;
  name: string;
  channel_id: string;
  player_config: PlayerConfig;
  is_active: boolean;
}

interface MediaItem {
  id: string;
  title: string;
  file_path: string;
  duration: number | null;
}

const SharedPlaylist = () => {
  const { shareId } = useParams();
  const [share, setShare] = useState<PlaylistShare | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [playlist, setPlaylist] = useState<MediaItem[]>([]);
  const [currentVideoUrl, setCurrentVideoUrl] = useState<string>("");
  const [syncData, setSyncData] = useState<{
    videoIndex: number;
    isPlaying: boolean;
  } | null>(null);

  // Load playlist from media library
  useEffect(() => {
    const loadPlaylist = async () => {
      try {
        const { data, error } = await supabase
          .from('media_library')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;
        if (data) {
          setPlaylist(data as MediaItem[]);
        }
      } catch (err) {
        console.error('Error loading playlist:', err);
      }
    };

    loadPlaylist();
  }, []);

  useEffect(() => {
    const fetchShare = async () => {
      if (!shareId) return;

      try {
        const { data, error } = await supabase
          .from('playlist_shares')
          .select('*')
          .eq('share_id', shareId)
          .eq('is_active', true)
          .single();

        if (error) throw error;

        if (data) {
          setShare(data as unknown as PlaylistShare);
          
          // Apply custom colors
          const root = document.documentElement;
          const config = data.player_config as unknown as PlayerConfig;
          root.style.setProperty('--primary', config.primaryColor);
          root.style.setProperty('--background', config.backgroundColor);
          root.style.setProperty('--foreground', config.textColor);
        } else {
          setError("Partage introuvable ou inactif");
        }
      } catch (err: any) {
        console.error('Error fetching share:', err);
        setError(err.message || "Erreur lors du chargement");
      } finally {
        setLoading(false);
      }
    };

    fetchShare();
  }, [shareId]);

  // Subscribe to real-time sync updates
  useEffect(() => {
    if (!shareId) return;

    const channel = supabase
      .channel(`sync:${shareId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'playlist_sync_state',
          filter: `share_id=eq.${shareId}`
        },
        (payload) => {
          console.log('Sync update received:', payload);
          if (payload.new) {
            const newData = payload.new as any;
            setSyncData({
              videoIndex: newData.current_video_index,
              isPlaying: newData.is_playing,
            });
          }
        }
      )
      .subscribe();

    // Fetch initial sync state
    const fetchInitialSync = async () => {
      const { data } = await supabase
        .from('playlist_sync_state')
        .select('*')
        .eq('share_id', shareId)
        .single();
      
      if (data) {
        setSyncData({
          videoIndex: data.current_video_index,
          isPlaying: data.is_playing,
        });
      }
    };

    fetchInitialSync();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [shareId]);

  // Update current video URL when sync data changes
  useEffect(() => {
    if (syncData && playlist.length > 0 && syncData.videoIndex < playlist.length) {
      const currentVideo = playlist[syncData.videoIndex];
      const { data } = supabase.storage
        .from("media-library")
        .getPublicUrl(currentVideo.file_path);
      setCurrentVideoUrl(data.publicUrl);
    }
  }, [syncData?.videoIndex, playlist]);

  // Handle video end - auto loop playlist
  const handleVideoEnded = async () => {
    if (!shareId || playlist.length === 0) return;

    const nextIndex = syncData ? (syncData.videoIndex + 1) % playlist.length : 0;
    
    console.log('Video ended, advancing to next:', nextIndex);
    
    // Update sync state for next video
    await supabase
      .from('playlist_sync_state')
      .update({
        current_video_index: nextIndex,
        is_playing: true,
        playback_time: 0
      })
      .eq('share_id', shareId);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  if (error || !share) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 max-w-md w-full text-center">
          <h1 className="text-2xl font-bold text-destructive mb-2">Erreur</h1>
          <p className="text-muted-foreground">{error || "Partage introuvable"}</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4 md:p-8 max-w-6xl">
        <Card className="bg-card border-border overflow-hidden">
          <div className="p-4 border-b border-border">
            <h1 className="text-foreground text-2xl font-bold">{share.name}</h1>
            <p className="text-muted-foreground text-sm mt-1">Lecture en temps réel synchronisée</p>
          </div>
          
          <div className="p-4">
            {currentVideoUrl && syncData ? (
              <>
                <VideoPlayer
                  src={currentVideoUrl}
                  className="w-full aspect-video rounded-lg overflow-hidden"
                  autoPlay={syncData.isPlaying}
                  controls={true}
                  onEnded={handleVideoEnded}
                />
                <div className="mt-2 text-xs text-muted-foreground text-center">
                  🔴 En direct • Vidéo {syncData.videoIndex + 1} / {playlist.length} • {syncData.isPlaying ? 'En lecture' : 'En pause'}
                </div>
              </>
            ) : (
              <div className="w-full aspect-video rounded-lg bg-muted flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-2" />
                  <p className="text-muted-foreground text-sm">En attente de la diffusion...</p>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-border">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Chaîne:</span>
              <span className="text-foreground font-semibold">{share.channel_id}</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default SharedPlaylist;