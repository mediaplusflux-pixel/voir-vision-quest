import Header from "@/components/Header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useChannelBroadcast } from "@/hooks/useChannelBroadcast";
import { useState } from "react";
import { Radio, Save } from "lucide-react";

const Transmission = () => {
  const { configureTransmission } = useChannelBroadcast();
  const [channelId, setChannelId] = useState("");
  const [protocol, setProtocol] = useState("rtmp");
  const [url, setUrl] = useState("");

  const handleSave = () => {
    if (channelId && url) {
      configureTransmission(channelId, protocol, url);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="p-8">
        <h1 className="text-foreground text-3xl font-bold mb-8 flex items-center gap-3">
          <Radio className="w-8 h-8" />
          Transmission TNT
        </h1>
        
        <Card className="bg-card border-border p-8 max-w-2xl">
          <h2 className="text-foreground text-xl font-semibold mb-6">
            Configuration de la transmission
          </h2>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="channelId" className="text-foreground">
                ID de la chaîne
              </Label>
              <Input
                id="channelId"
                placeholder="Entrez l'ID de la chaîne"
                value={channelId}
                onChange={(e) => setChannelId(e.target.value)}
                className="bg-background border-border text-foreground"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="protocol" className="text-foreground">
                Protocole de diffusion
              </Label>
              <Select value={protocol} onValueChange={setProtocol}>
                <SelectTrigger className="bg-background border-border text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rtmp">RTMP</SelectItem>
                  <SelectItem value="srt">SRT</SelectItem>
                  <SelectItem value="hls">HLS</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="url" className="text-foreground">
                URL de destination
              </Label>
              <Input
                id="url"
                placeholder="rtmp://exemple.com/live/stream"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="bg-background border-border text-foreground"
              />
              <p className="text-muted-foreground text-sm">
                Entrez l'URL complète de diffusion TNT
              </p>
            </div>

            <Button 
              onClick={handleSave} 
              className="w-full"
              disabled={!channelId || !url}
            >
              <Save className="w-4 h-4 mr-2" />
              Enregistrer la configuration
            </Button>
          </div>
        </Card>

        <Card className="bg-card border-border p-6 max-w-2xl mt-6">
          <h3 className="text-foreground font-semibold mb-3">Informations</h3>
          <ul className="space-y-2 text-muted-foreground text-sm">
            <li>• RTMP : Protocole standard pour la diffusion en direct</li>
            <li>• SRT : Protocole sécurisé pour la transmission vidéo</li>
            <li>• HLS : Format de streaming adaptatif HTTP</li>
          </ul>
        </Card>
      </div>
    </div>
  );
};

export default Transmission;
