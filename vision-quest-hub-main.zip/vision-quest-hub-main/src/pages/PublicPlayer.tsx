import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import VideoPlayer from "@/components/VideoPlayer";
import { Loader2 } from "lucide-react";

interface MediaItem {
  id: string;
  title: string;
  file_path: string;
  duration: number | null;
}

const generateSessionId = () => {
  return `viewer-${Math.random().toString(36).substring(2, 15)}`;
};

const PublicPlayer = () => {
  const [playlist, setPlaylist] = useState<MediaItem[]>([]);
  const [currentVideoUrl, setCurrentVideoUrl] = useState<string>("");
  const [syncData, setSyncData] = useState<{
    videoIndex: number;
    isPlaying: boolean;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [shareId, setShareId] = useState<string | null>(null);
  const sessionIdRef = useRef(generateSessionId());
  const heartbeatIntervalRef = useRef<NodeJS.Timeout>();

  // Track viewer presence
  useEffect(() => {
    if (!shareId) return;

    const channelId = 'zeedboda';
    const updatePresence = async () => {
      await supabase
        .from('channel_viewers')
        .upsert({
          channel_id: channelId,
          viewer_session_id: sessionIdRef.current,
          last_seen: new Date().toISOString()
        }, {
          onConflict: 'channel_id,viewer_session_id'
        });
    };

    // Initial presence
    updatePresence();

    // Heartbeat every 30 seconds
    heartbeatIntervalRef.current = setInterval(updatePresence, 30000);

    // Cleanup on unmount
    return () => {
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
      }
      // Remove viewer session
      supabase
        .from('channel_viewers')
        .delete()
        .eq('viewer_session_id', sessionIdRef.current)
        .then(() => console.log('Viewer session removed'));
    };
  }, [shareId]);

  // Load playlist from media library
  useEffect(() => {
    const loadPlaylist = async () => {
      try {
        const { data, error } = await supabase
          .from('media_library')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;
        if (data) {
          setPlaylist(data as MediaItem[]);
        }
      } catch (err) {
        console.error('Error loading playlist:', err);
      } finally {
        setLoading(false);
      }
    };

    loadPlaylist();
  }, []);

  // Subscribe to real-time sync updates from the active share
  useEffect(() => {
    const fetchActiveShare = async () => {
      const { data } = await supabase
        .from('playlist_shares')
        .select('share_id')
        .eq('is_active', true)
        .maybeSingle();

      if (data) {
        const activeShareId = data.share_id;
        setShareId(activeShareId);

        // Subscribe to sync state changes
        const channel = supabase
          .channel(`public-sync:${activeShareId}`)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'playlist_sync_state',
              filter: `share_id=eq.${activeShareId}`
            },
            (payload) => {
              console.log('Sync update received:', payload);
              if (payload.new) {
                const newData = payload.new as any;
                setSyncData({
                  videoIndex: newData.current_video_index,
                  isPlaying: newData.is_playing,
                });
              }
            }
          )
          .subscribe();

        // Fetch initial sync state
        const { data: syncState } = await supabase
          .from('playlist_sync_state')
          .select('*')
          .eq('share_id', activeShareId)
          .maybeSingle();
        
        if (syncState) {
          setSyncData({
            videoIndex: syncState.current_video_index,
            isPlaying: syncState.is_playing,
          });
        } else {
          // Initialize sync state if it doesn't exist
          await supabase
            .from('playlist_sync_state')
            .insert({
              share_id: activeShareId,
              current_video_index: 0,
              is_playing: true,
              playback_time: 0
            });
          
          setSyncData({
            videoIndex: 0,
            isPlaying: true,
          });
        }

        return () => {
          supabase.removeChannel(channel);
        };
      }
    };

    fetchActiveShare();
  }, []);

  // Update current video URL when sync data changes
  useEffect(() => {
    if (syncData && playlist.length > 0 && syncData.videoIndex < playlist.length) {
      const currentVideo = playlist[syncData.videoIndex];
      const { data } = supabase.storage
        .from("media-library")
        .getPublicUrl(currentVideo.file_path);
      setCurrentVideoUrl(data.publicUrl);
    }
  }, [syncData?.videoIndex, playlist]);

  // Handle video end - auto loop playlist
  const handleVideoEnded = async () => {
    if (!shareId || playlist.length === 0) return;

    const nextIndex = syncData ? (syncData.videoIndex + 1) % playlist.length : 0;
    
    // Update sync state for next video
    await supabase
      .from('playlist_sync_state')
      .update({
        current_video_index: nextIndex,
        is_playing: true,
        playback_time: 0
      })
      .eq('share_id', shareId);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Chargement du flux en direct...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      {currentVideoUrl && syncData ? (
        <div className="relative w-full h-screen">
          <VideoPlayer
            src={currentVideoUrl}
            className="w-full h-full"
            autoPlay={syncData.isPlaying}
            controls={true}
            onEnded={handleVideoEnded}
          />
          <div className="absolute top-4 left-4 bg-black/80 text-white px-4 py-2 rounded-lg backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              <span className="text-sm font-semibold">EN DIRECT</span>
              <span className="text-xs text-gray-300">
                Vidéo {syncData.videoIndex + 1} / {playlist.length}
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="w-full h-screen flex items-center justify-center bg-muted">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">En attente de la diffusion...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default PublicPlayer;
