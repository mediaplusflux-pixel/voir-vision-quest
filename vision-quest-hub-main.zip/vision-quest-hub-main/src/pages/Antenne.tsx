import { Play, Pause, Trash2, Eye, Radio, Tv, Power, SkipForward, List, Scissors } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import VideoPlayer from "@/components/VideoPlayer";
import Header from "@/components/Header";
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePlaylist } from "@/contexts/PlaylistContext";
import { useChannelBroadcast } from "@/hooks/useChannelBroadcast";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { SharePlaylistDialog } from "@/components/SharePlaylistDialog";

const Antenne = () => {
  const { playlist, currentIndex, setCurrentIndex, isPlaying, setIsPlaying, playMode, setPlayMode } = usePlaylist();
  const { broadcasts, isLoading, startBroadcast, stopBroadcast } = useChannelBroadcast();
  const [isLive, setIsLive] = useState(false);
  const [activeSource, setActiveSource] = useState<'playlist' | 'live'>('playlist');
  const [currentVideoUrl, setCurrentVideoUrl] = useState<string>("");
  const [liveVideoUrl, setLiveVideoUrl] = useState<string>(""); // URL diffusée à l'antenne
  const [liveVideoTitle, setLiveVideoTitle] = useState<string>(""); // Titre de la vidéo à l'antenne
  const [currentShareId, setCurrentShareId] = useState<string | null>(null);
  const [currentPlaybackTime, setCurrentPlaybackTime] = useState(0);
  const { toast } = useToast();

  const channelId = "zeedboda";
  const broadcast = broadcasts[channelId];

  // Auto-start playlist in loop mode on component mount
  useEffect(() => {
    if (playlist.length > 0 && !isLive) {
      setIsPlaying(true);
      setPlayMode('loop');
    }
  }, [playlist.length]);

  // Sync playlist state to database for real-time sharing
  useEffect(() => {
    if (!currentShareId || !isLive) return;

    const syncState = async () => {
      try {
        const currentVideo = playlist[currentIndex];
        await supabase
          .from('playlist_sync_state')
          .upsert({
            share_id: currentShareId,
            current_video_index: currentIndex,
            playback_time: currentPlaybackTime,
            is_playing: isPlaying,
            video_duration: currentVideo?.duration || null,
          }, {
            onConflict: 'share_id'
          });
      } catch (error) {
        console.error('Error syncing state:', error);
      }
    };

    syncState();
  }, [currentShareId, currentIndex, isPlaying, playlist, isLive, currentPlaybackTime]);

  // Update playback time periodically
  useEffect(() => {
    if (!isPlaying || !isLive) return;

    const interval = setInterval(() => {
      setCurrentPlaybackTime((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying, isLive]);

  // Load active share for this channel
  useEffect(() => {
    const loadActiveShare = async () => {
      try {
        const { data } = await supabase
          .from('playlist_shares')
          .select('share_id')
          .eq('channel_id', channelId)
          .eq('is_active', true)
          .single();
        
        if (data) {
          setCurrentShareId(data.share_id);
        }
      } catch (error) {
        console.error('Error loading share:', error);
      }
    };

    loadActiveShare();
  }, [channelId]);

  // Update preview video URL when playlist changes
  useEffect(() => {
    if (playlist.length > 0 && currentIndex < playlist.length) {
      const currentVideo = playlist[currentIndex];
      const { data } = supabase.storage
        .from("media-library")
        .getPublicUrl(currentVideo.file_path);
      setCurrentVideoUrl(data.publicUrl);
    }
  }, [playlist, currentIndex]);

  // Bouton CUT - Envoie le contenu actuel vers l'antenne en direct
  const handleCut = () => {
    if (playlist.length === 0) {
      toast({
        title: "Playlist vide",
        description: "Ajoutez des vidéos à la playlist depuis la bibliothèque",
        variant: "destructive",
      });
      return;
    }

    // Transfert vers l'antenne en direct
    setLiveVideoUrl(currentVideoUrl);
    setLiveVideoTitle(playlist[currentIndex]?.title || "");
    setIsLive(true);
    setActiveSource('playlist');

    toast({
      title: "Cut effectué",
      description: `"${playlist[currentIndex]?.title}" est maintenant à l'antenne`,
    });
  };

  const handleStopAntenna = async () => {
    await stopBroadcast(channelId);
    setIsLive(false);
    setLiveVideoUrl("");
    setLiveVideoTitle("");
  };

  const handleNextVideo = () => {
    if (playMode === 'manual' && playlist.length > 0) {
      setCurrentIndex((currentIndex + 1) % playlist.length);
      setCurrentPlaybackTime(0);
    }
  };

  const handleVideoEnd = () => {
    // Auto-advance to next video in loop mode
    const nextIndex = (currentIndex + 1) % playlist.length;
    setCurrentIndex(nextIndex);
    setCurrentPlaybackTime(0);
    
    // Si l'antenne est live, mettre à jour aussi la vidéo diffusée
    if (isLive && activeSource === 'playlist') {
      const nextVideo = playlist[nextIndex];
      if (nextVideo) {
        const { data } = supabase.storage
          .from("media-library")
          .getPublicUrl(nextVideo.file_path);
        setLiveVideoUrl(data.publicUrl);
        setLiveVideoTitle(nextVideo.title);
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="p-8 space-y-6">
        {/* ECRAN ANTENNE EN DIRECT - Affiche ce qui est diffusé */}
        <div className="grid grid-cols-3 gap-6">
          <Card className="col-span-2 bg-card border-border">
            <div className="p-3 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Tv className="w-5 h-5 text-primary" />
                <h2 className="text-foreground text-xl font-bold">ANTENNE EN DIRECT</h2>
                <span className={`ml-4 text-sm ${isLive ? "text-green-500 font-semibold" : "text-destructive font-semibold"}`}>
                  {isLive ? "● DIFFUSION EN COURS" : "HORS ANTENNE"}
                </span>
              </div>
            </div>
            <div className="p-3">
              {isLive && liveVideoUrl ? (
                <VideoPlayer
                  src={liveVideoUrl}
                  className="w-full aspect-video max-h-[280px]"
                  autoPlay={true}
                  onEnded={handleVideoEnd}
                />
              ) : (
                <div className="w-full aspect-video max-h-[280px] bg-black rounded flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <Tv className="w-12 h-12 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">Aucune diffusion en cours</p>
                    <p className="text-xs mt-1">Utilisez "Cut" pour envoyer du contenu</p>
                  </div>
                </div>
              )}
              <div className="mt-3 grid grid-cols-4 gap-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Source:</span>
                  <span className="text-foreground font-semibold">
                    {isLive ? (activeSource === 'playlist' ? 'Playlist' : 'Live') : '-'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">En cours:</span>
                  <span className="text-foreground font-semibold truncate max-w-[100px]">
                    {isLive ? liveVideoTitle : '-'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Spectateurs:</span>
                  <span className="text-foreground">{isLive ? "0" : "-"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bitrate:</span>
                  <span className="text-foreground">{isLive ? "2500 kbps" : "-"}</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Panneau Partage Playlist à droite */}
          <Card className="bg-card border-border p-4">
            <h3 className="text-foreground text-lg font-bold mb-4">Partage & Diffusion</h3>
            <div className="space-y-4">
              <SharePlaylistDialog channelId={channelId} />
              <div className="border-t border-border pt-4">
                <h4 className="text-foreground text-sm font-semibold mb-2">Statut antenne</h4>
                <p className={`text-sm font-semibold ${isLive ? "text-green-500" : "text-muted-foreground"}`}>
                  {isLive ? "En diffusion" : "Hors ligne"}
                </p>
                {isLive && liveVideoTitle && (
                  <p className="text-xs text-muted-foreground mt-1 truncate">
                    {liveVideoTitle}
                  </p>
                )}
              </div>
              <div className="border-t border-border pt-4">
                <h4 className="text-foreground text-sm font-semibold mb-2">Spectateurs</h4>
                <p className="text-2xl font-bold text-foreground">{isLive ? "0" : "-"}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Boutons de contrôle principaux */}
        <div className="flex justify-center gap-4">
          <Button
            variant="secondary"
            size="lg"
            onClick={() => setPlayMode(playMode === 'loop' ? 'manual' : 'loop')}
            className="min-w-[200px]"
          >
            {playMode === 'loop' ? 'Mode: Boucle' : 'Mode: Manuel'}
          </Button>
          {playMode === 'manual' && (
            <Button
              variant="secondary"
              size="lg"
              onClick={handleNextVideo}
              className="min-w-[200px]"
            >
              <SkipForward className="w-5 h-5 mr-2" />
              Vidéo suivante
            </Button>
          )}
          <Button
            variant="destructive"
            size="lg"
            onClick={handleStopAntenna}
            disabled={!isLive}
            className="min-w-[200px]"
          >
            <Pause className="w-5 h-5 mr-2" />
            Arrêter l'antenne
          </Button>
        </div>

        {/* ONGLETS PROGRAM / LIVE */}
        <Tabs defaultValue="playlist" className="w-full" onValueChange={(v) => setActiveSource(v as 'playlist' | 'live')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="playlist">PROGRAM (Playlist)</TabsTrigger>
            <TabsTrigger value="live">LIVE (Antenne)</TabsTrigger>
          </TabsList>

          <TabsContent value="playlist" className="space-y-4 mt-4">
            <div className="grid grid-cols-3 gap-6">
              {/* Aperçu Playlist */}
              <Card className="col-span-2 bg-card border-border">
                <div className="p-4 border-b border-border">
                  <h3 className="text-foreground text-xl font-bold">Aperçu Playlist</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Prévisualisation du contenu avant diffusion
                  </p>
                </div>
                <div className="p-4">
                  {playlist.length > 0 ? (
                    <>
                      <VideoPlayer
                        src={currentVideoUrl}
                        className="w-full aspect-video"
                        autoPlay={isPlaying}
                        onEnded={handleVideoEnd}
                        onTimeUpdate={(e) => {
                          const videoElement = e.target as HTMLVideoElement;
                          setCurrentPlaybackTime(Math.floor(videoElement.currentTime));
                        }}
                      />
                      <div className="mt-4 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">En lecture:</span>
                          <span className="text-foreground font-semibold">{playlist[currentIndex]?.title}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Vidéo:</span>
                          <span className="text-foreground">{currentIndex + 1}/{playlist.length}</span>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="w-full aspect-video bg-muted rounded flex items-center justify-center">
                      <div className="text-center text-muted-foreground">
                        <List className="w-12 h-12 mx-auto mb-2" />
                        <p>Aucune playlist chargée</p>
                        <p className="text-sm mt-1">Ajoutez des vidéos depuis la bibliothèque</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              {/* Contrôles Playlist avec bouton CUT */}
              <Card className="bg-card border-border p-6">
                <h3 className="text-foreground text-xl font-bold mb-4">Contrôles Playlist</h3>
                {playlist.length > 0 ? (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-foreground text-sm font-semibold mb-2">En lecture</h4>
                      <p className="text-foreground text-lg">{playlist[currentIndex]?.title || 'N/A'}</p>
                      <p className="text-muted-foreground text-sm">Vidéo {currentIndex + 1}/{playlist.length}</p>
                    </div>

                    {/* Bouton CUT - Principal */}
                    <Button
                      variant="default"
                      size="lg"
                      className="w-full bg-red-600 hover:bg-red-700 text-white font-bold"
                      onClick={handleCut}
                    >
                      <Scissors className="w-5 h-5 mr-2" />
                      CUT
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      Envoyer cette playlist à l'antenne en direct
                    </p>

                    <div className="flex gap-2">
                      <Button
                        variant="secondary"
                        className="flex-1"
                        onClick={() => setIsPlaying(!isPlaying)}
                      >
                        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </Button>
                      {playMode === 'manual' && (
                        <Button
                          variant="secondary"
                          className="flex-1"
                          onClick={handleNextVideo}
                        >
                          <SkipForward className="w-4 h-4" />
                        </Button>
                      )}
                    </div>

                    <div className="border-t border-border pt-4">
                      <h4 className="text-foreground text-sm font-semibold mb-2">Suivant</h4>
                      <p className="text-muted-foreground text-sm">
                        {playlist[(currentIndex + 1) % playlist.length]?.title || 'N/A'}
                      </p>
                    </div>

                    <div className="border-t border-border pt-4">
                      <h4 className="text-foreground text-sm font-semibold mb-2">Mode de lecture</h4>
                      <p className="text-muted-foreground text-sm">
                        {playMode === 'loop' ? 'Boucle automatique' : 'Avancement manuel'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    <p>Aucune playlist chargée</p>
                  </div>
                )}
              </Card>
            </div>

            {/* Liste des programmes */}
            <Card className="bg-card border-border p-6">
              <h3 className="text-foreground text-xl font-bold mb-4">Programmes en playlist ({playlist.length}/20)</h3>
              {playlist.length > 0 ? (
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {playlist.map((item, index) => (
                    <div
                      key={item.id}
                      className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                        index === currentIndex && isPlaying
                          ? 'bg-primary/20 border-2 border-primary'
                          : 'bg-secondary hover:bg-secondary/80'
                      }`}
                    >
                      <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                        {index + 1}
                      </div>
                      <img
                        src={item.thumbnail || "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&h=300&fit=crop"}
                        alt={item.title}
                        className="w-20 h-14 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h4 className="text-foreground font-semibold">{item.title}</h4>
                        <p className="text-muted-foreground text-sm">
                          {item.duration ? `${Math.floor(item.duration / 60)}m ${Math.floor(item.duration % 60)}s` : 'N/A'}
                        </p>
                      </div>
                      {index === currentIndex && isPlaying && (
                        <div className="flex items-center gap-1 text-primary">
                          <Play className="w-4 h-4 fill-current" />
                          <span className="text-xs font-semibold">EN COURS</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <List className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Aucune vidéo dans la playlist</p>
                  <p className="text-sm mt-1">Ajoutez des vidéos depuis la bibliothèque</p>
                </div>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="live" className="mt-4">
            <div className="grid grid-cols-3 gap-6">
              <Card className="col-span-2 bg-card border-border">
                <div className="p-4 border-b border-border">
                  <h3 className="text-foreground text-xl font-bold">Live Stream Input</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Flux live pour retransmission directe à l'antenne
                  </p>
                </div>
                <div className="p-4">
                  <VideoPlayer className="w-full aspect-video" />
                  <div className="mt-4 space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">URL d'entrée:</span>
                      <span className="text-foreground font-mono text-xs">rtmp://...</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Status:</span>
                      <span className="text-muted-foreground">Non connecté</span>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Contrôles Live avec bouton CUT */}
              <Card className="bg-card border-border p-6">
                <h3 className="text-foreground text-xl font-bold mb-4">Contrôles Live</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-foreground text-sm font-semibold mb-2">Source Live</h4>
                    <p className="text-muted-foreground text-sm">Aucun flux connecté</p>
                  </div>

                  {/* Bouton CUT pour Live */}
                  <Button
                    variant="default"
                    size="lg"
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-bold"
                    disabled={true}
                    onClick={() => {
                      setActiveSource('live');
                      setIsLive(true);
                      toast({
                        title: "Cut effectué",
                        description: "Le flux live est maintenant à l'antenne",
                      });
                    }}
                  >
                    <Scissors className="w-5 h-5 mr-2" />
                    CUT
                  </Button>
                  <p className="text-xs text-muted-foreground text-center">
                    Envoyer ce flux live à l'antenne en direct
                  </p>

                  <Button variant="secondary" className="w-full">
                    Configurer le flux live
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Antenne;
