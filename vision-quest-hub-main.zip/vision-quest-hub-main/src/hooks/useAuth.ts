import { useEffect, useState, useRef } from "react";
import { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export const useAuth = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);
  const mountedRef = useRef(true);
  const sessionRef = useRef<Session | null>(null);

  useEffect(() => {
    mountedRef.current = true;

    // 1. D'abord configurer le listener AVANT de récupérer la session
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, currentSession) => {
        if (!mountedRef.current) return;

        // Log simple pour debug
        console.log('Auth event:', event);

        // IMPORTANT: Ne jamais appeler de fonctions async Supabase ici!
        // Cela cause un deadlock.
        
        if (event === 'SIGNED_OUT') {
          // Pour SIGNED_OUT, vérifier si on a une session en mémoire
          // Si oui, c'est probablement un faux SIGNED_OUT dû à une erreur réseau
          if (sessionRef.current) {
            console.log('Ignoring SIGNED_OUT, session exists in memory');
            return;
          }
          setSession(null);
          sessionRef.current = null;
        } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
          if (currentSession) {
            setSession(currentSession);
            sessionRef.current = currentSession;
          }
        }

        if (!initialized) {
          setInitialized(true);
          setLoading(false);
        }
      }
    );

    // 2. Ensuite récupérer la session existante
    supabase.auth.getSession().then(({ data: { session: existingSession } }) => {
      if (mountedRef.current) {
        if (existingSession) {
          setSession(existingSession);
          sessionRef.current = existingSession;
        }
        setInitialized(true);
        setLoading(false);
      }
    });

    return () => {
      mountedRef.current = false;
      subscription.unsubscribe();
    };
  }, []);

  return { session, loading, initialized };
};
