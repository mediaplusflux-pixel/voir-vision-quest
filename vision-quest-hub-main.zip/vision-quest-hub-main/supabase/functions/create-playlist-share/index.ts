import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ success: false, error: 'Non autorisé' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      return new Response(
        JSON.stringify({ success: false, error: 'Non autorisé' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { name, channelId, playerConfig, scheduledTime, startImmediately } = await req.json();

    if (!name || !channelId) {
      return new Response(
        JSON.stringify({ success: false, error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Determine status based on scheduling
    let status = 'idle';
    let scheduled_start_time = null;
    
    if (startImmediately) {
      status = 'live';
    } else if (scheduledTime) {
      status = 'scheduled';
      scheduled_start_time = scheduledTime;
    }

    // Generate unique share ID
    const shareId = crypto.randomUUID().split('-')[0];

    // Insert share into database
    const { data, error } = await supabaseClient
      .from('playlist_shares')
      .insert({
        share_id: shareId,
        name,
        channel_id: channelId,
        user_id: user.id,
        status,
        scheduled_start_time,
        player_config: playerConfig || {
          primaryColor: "18 100% 60%",
          backgroundColor: "0 0% 7%",
          textColor: "0 0% 98%"
        }
      })
      .select()
      .single();

    if (error) {
      console.error('Database error:', error);
      return new Response(
        JSON.stringify({ success: false, error: error.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Playlist share created:', data);

    // If starting immediately, initialize sync state
    if (status === 'live') {
      const { error: syncError } = await supabaseClient
        .from('playlist_sync_state')
        .insert({
          share_id: shareId,
          current_video_index: 0,
          is_playing: true,
          playback_time: 0,
          auto_advance: true,
          started_at: new Date().toISOString()
        });

      if (syncError) {
        console.error('Error creating sync state:', syncError);
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        shareId: data.share_id,
        status: data.status,
        scheduledTime: data.scheduled_start_time,
        data 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});