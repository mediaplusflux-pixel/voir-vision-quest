import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Checking for scheduled playlists to start...');

    // Call the database function to start scheduled playlists
    const { error: functionError } = await supabaseClient.rpc('start_scheduled_playlists');

    if (functionError) {
      console.error('Error starting scheduled playlists:', functionError);
      return new Response(
        JSON.stringify({ success: false, error: functionError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get currently live playlists
    const { data: livePlaylists, error: selectError } = await supabaseClient
      .from('playlist_shares')
      .select('share_id, name, status')
      .eq('status', 'live')
      .eq('is_active', true);

    if (selectError) {
      console.error('Error fetching live playlists:', selectError);
    }

    console.log('Playlist scheduler ran successfully', {
      livePlaylistsCount: livePlaylists?.length || 0,
      livePlaylists
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Playlist scheduler executed',
        livePlaylistsCount: livePlaylists?.length || 0
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
