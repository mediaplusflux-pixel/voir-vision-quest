-- Create playlist sync state table for real-time synchronization
CREATE TABLE IF NOT EXISTS public.playlist_sync_state (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  share_id TEXT NOT NULL UNIQUE REFERENCES public.playlist_shares(share_id) ON DELETE CASCADE,
  current_video_index INTEGER NOT NULL DEFAULT 0,
  playback_time NUMERIC NOT NULL DEFAULT 0,
  is_playing BOOLEAN NOT NULL DEFAULT false,
  video_duration NUMERIC,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.playlist_sync_state ENABLE ROW LEVEL SECURITY;

-- Allow public read access to sync state
CREATE POLICY "Allow public read access to sync state"
  ON public.playlist_sync_state
  FOR SELECT
  USING (true);

-- Allow anyone to insert sync state
CREATE POLICY "Allow insert sync state"
  ON public.playlist_sync_state
  FOR INSERT
  WITH CHECK (true);

-- Allow anyone to update sync state
CREATE POLICY "Allow update sync state"
  ON public.playlist_sync_state
  FOR UPDATE
  USING (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.playlist_sync_state;

-- Create index for faster lookups
CREATE INDEX idx_playlist_sync_state_share_id ON public.playlist_sync_state(share_id);