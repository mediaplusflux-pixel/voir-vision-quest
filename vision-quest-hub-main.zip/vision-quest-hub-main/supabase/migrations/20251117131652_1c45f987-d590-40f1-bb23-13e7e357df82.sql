-- Create table for playlist shares
CREATE TABLE IF NOT EXISTS public.playlist_shares (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  share_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  player_config JSONB DEFAULT '{
    "primaryColor": "18 100% 60%",
    "backgroundColor": "0 0% 7%",
    "textColor": "0 0% 98%"
  }'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.playlist_shares ENABLE ROW LEVEL SECURITY;

-- Allow public read access to active shares
CREATE POLICY "Allow public read access to active shares"
  ON public.playlist_shares
  FOR SELECT
  USING (is_active = true);

-- Allow insert for anyone (they can create shares)
CREATE POLICY "Allow insert for anyone"
  ON public.playlist_shares
  FOR INSERT
  WITH CHECK (true);

-- Allow update for anyone (they can update their shares)
CREATE POLICY "Allow update for anyone"
  ON public.playlist_shares
  FOR UPDATE
  USING (true);

-- Create index on share_id for faster lookups
CREATE INDEX idx_playlist_shares_share_id ON public.playlist_shares(share_id);

-- Create index on channel_id for faster lookups
CREATE INDEX idx_playlist_shares_channel_id ON public.playlist_shares(channel_id);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_playlist_shares_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER playlist_shares_updated_at
  BEFORE UPDATE ON public.playlist_shares
  FOR EACH ROW
  EXECUTE FUNCTION update_playlist_shares_updated_at();