-- Create media_library table
CREATE TABLE public.media_library (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  duration INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  type TEXT NOT NULL,
  file_path TEXT NOT NULL,
  thumbnail TEXT
);

-- Enable Row Level Security
ALTER TABLE public.media_library ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (since this is a broadcast system)
CREATE POLICY "Anyone can view media"
ON public.media_library
FOR SELECT
USING (true);

CREATE POLICY "Anyone can insert media"
ON public.media_library
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can update media"
ON public.media_library
FOR UPDATE
USING (true);

CREATE POLICY "Anyone can delete media"
ON public.media_library
FOR DELETE
USING (true);

-- Create storage bucket for media files
INSERT INTO storage.buckets (id, name, public)
VALUES ('media-library', 'media-library', true);

-- Create storage policies for public access
CREATE POLICY "Anyone can view media files"
ON storage.objects
FOR SELECT
USING (bucket_id = 'media-library');

CREATE POLICY "Anyone can upload media files"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'media-library');

CREATE POLICY "Anyone can update media files"
ON storage.objects
FOR UPDATE
USING (bucket_id = 'media-library');

CREATE POLICY "Anyone can delete media files"
ON storage.objects
FOR DELETE
USING (bucket_id = 'media-library');