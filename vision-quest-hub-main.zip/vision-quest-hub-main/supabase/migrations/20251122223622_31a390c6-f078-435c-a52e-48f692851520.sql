-- Supprimer l'ancienne politique restrictive
DROP POLICY IF EXISTS "Users can view their own media" ON public.media_library;

-- Créer une nouvelle politique qui permet:
-- 1. Aux utilisateurs de voir leurs propres médias
-- 2. À tout le monde de voir les médias (pour les playlists partagées publiques)
CREATE POLICY "Allow public read access to media" 
ON public.media_library 
FOR SELECT 
USING (true);

-- Garder les autres politiques d'écriture strictes
-- (INSERT, UPDATE, DELETE restent limités au propriétaire)