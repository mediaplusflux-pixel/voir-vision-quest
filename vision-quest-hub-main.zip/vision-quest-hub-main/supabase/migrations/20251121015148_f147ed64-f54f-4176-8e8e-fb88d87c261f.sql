-- Add scheduled_start_time to playlist_shares
ALTER TABLE public.playlist_shares 
ADD COLUMN IF NOT EXISTS scheduled_start_time timestamp with time zone,
ADD COLUMN IF NOT EXISTS status text DEFAULT 'idle' CHECK (status IN ('idle', 'scheduled', 'live', 'stopped'));

-- Add index for scheduled playlists
CREATE INDEX IF NOT EXISTS idx_playlist_shares_scheduled 
ON public.playlist_shares(scheduled_start_time) 
WHERE status = 'scheduled' AND is_active = true;

-- Update playlist_sync_state to handle continuous playback
ALTER TABLE public.playlist_sync_state
ADD COLUMN IF NOT EXISTS auto_advance boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS started_at timestamp with time zone;

-- Create function to auto-start scheduled playlists
CREATE OR REPLACE FUNCTION public.start_scheduled_playlists()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update status to 'live' for playlists that should start now
  UPDATE public.playlist_shares
  SET status = 'live',
      updated_at = now()
  WHERE status = 'scheduled'
    AND is_active = true
    AND scheduled_start_time <= now();
    
  -- Initialize sync state for newly started playlists
  INSERT INTO public.playlist_sync_state (share_id, is_playing, current_video_index, started_at, auto_advance)
  SELECT share_id, true, 0, now(), true
  FROM public.playlist_shares
  WHERE status = 'live'
    AND is_active = true
    AND NOT EXISTS (
      SELECT 1 FROM public.playlist_sync_state 
      WHERE playlist_sync_state.share_id = playlist_shares.share_id
    )
  ON CONFLICT (share_id) DO NOTHING;
END;
$$;

-- Create function to advance playlist automatically
CREATE OR REPLACE FUNCTION public.advance_playlist(p_share_id text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_max_index integer;
BEGIN
  -- Get the maximum video index for this playlist (assuming channel_id maps to videos)
  -- This is a placeholder - you'll need to adjust based on your actual media library structure
  
  -- Advance to next video or loop back to 0
  UPDATE public.playlist_sync_state
  SET current_video_index = CASE 
    WHEN auto_advance THEN (current_video_index + 1)
    ELSE current_video_index
  END,
  playback_time = 0,
  updated_at = now()
  WHERE share_id = p_share_id;
END;
$$;