-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- Add user_id to media_library
ALTER TABLE public.media_library ADD COLUMN user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Add user_id to playlist_shares
ALTER TABLE public.playlist_shares ADD COLUMN user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update media_library RLS policies
DROP POLICY IF EXISTS "Anyone can view media" ON public.media_library;
DROP POLICY IF EXISTS "Anyone can insert media" ON public.media_library;
DROP POLICY IF EXISTS "Anyone can update media" ON public.media_library;
DROP POLICY IF EXISTS "Anyone can delete media" ON public.media_library;

CREATE POLICY "Users can view their own media"
  ON public.media_library FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own media"
  ON public.media_library FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own media"
  ON public.media_library FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own media"
  ON public.media_library FOR DELETE
  USING (auth.uid() = user_id);

-- Update playlist_shares RLS policies
DROP POLICY IF EXISTS "Allow insert for anyone" ON public.playlist_shares;
DROP POLICY IF EXISTS "Allow public read access to active shares" ON public.playlist_shares;
DROP POLICY IF EXISTS "Allow update for anyone" ON public.playlist_shares;

CREATE POLICY "Users can view their own shares"
  ON public.playlist_shares FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Public can view active shares"
  ON public.playlist_shares FOR SELECT
  USING (is_active = true);

CREATE POLICY "Users can insert their own shares"
  ON public.playlist_shares FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own shares"
  ON public.playlist_shares FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own shares"
  ON public.playlist_shares FOR DELETE
  USING (auth.uid() = user_id);

-- Create trigger function for new user profiles
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email);
  RETURN NEW;
END;
$$;

-- Create trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Delete existing data (old videos without user_id)
DELETE FROM public.media_library WHERE user_id IS NULL;
DELETE FROM public.playlist_shares WHERE user_id IS NULL;

-- Make user_id required
ALTER TABLE public.media_library ALTER COLUMN user_id SET NOT NULL;
ALTER TABLE public.playlist_shares ALTER COLUMN user_id SET NOT NULL;