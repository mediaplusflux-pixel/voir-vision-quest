-- Create table for tracking active viewers
CREATE TABLE IF NOT EXISTS public.channel_viewers (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  channel_id text NOT NULL,
  viewer_session_id text NOT NULL,
  last_seen timestamp with time zone DEFAULT now() NOT NULL,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  UNIQUE(channel_id, viewer_session_id)
);

-- Enable RLS
ALTER TABLE public.channel_viewers ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert/update their viewer session
CREATE POLICY "Anyone can insert viewer sessions"
  ON public.channel_viewers
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update viewer sessions"
  ON public.channel_viewers
  FOR UPDATE
  USING (true);

-- Allow anyone to read viewer counts
CREATE POLICY "Anyone can read viewer sessions"
  ON public.channel_viewers
  FOR SELECT
  USING (true);

-- Create function to clean up old viewer sessions (older than 1 minute)
CREATE OR REPLACE FUNCTION public.cleanup_old_viewers()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.channel_viewers
  WHERE last_seen < now() - interval '1 minute';
END;
$$;

-- Enable realtime for channel_viewers table
ALTER PUBLICATION supabase_realtime ADD TABLE public.channel_viewers;