-- Fix search_path for security
DROP TRIGGER IF EXISTS playlist_shares_updated_at ON public.playlist_shares;
DROP FUNCTION IF EXISTS update_playlist_shares_updated_at();

CREATE OR REPLACE FUNCTION update_playlist_shares_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER playlist_shares_updated_at
  BEFORE UPDATE ON public.playlist_shares
  FOR EACH ROW
  EXECUTE FUNCTION update_playlist_shares_updated_at();